<?php

namespace IntaSend\IntaSendPHP;

class Customer
{
    public $first_name;
    public $last_name;
    public $email;
    public $phone_number;
    public $country;
    public $city;
    public $address;
    public $state;
    public $zipcode;
}
